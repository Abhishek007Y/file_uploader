# frozen_string_literal: true

# app/controllers/home_controller.rb
class HomeController < ApplicationController
  def index
    # This action will load the home page with sign-up and login options
  end
end
